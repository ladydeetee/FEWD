$(document).ready(function() 

$("#tb").hover(
	function() {
	$.backstretch("therouxbred.jpg",{fade:300});
	}
);